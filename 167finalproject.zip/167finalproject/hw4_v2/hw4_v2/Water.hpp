//
//  Water.hpp
//  CSE167_group_proj
//
//  Created by 吴诗慧 on 2020/3/12.
//  Copyright © 2020年 SelenaWu. All rights reserved.
//

#ifndef Water_hpp
#define Water_hpp

#ifdef __APPLE__
#include <OpenGL/gl3.h>
#else
#include <GL/glew.h>
#endif

#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <vector>

#include "Object.h"
#include <stdio.h>
#include <string.h>
#include <vector>
#include <iostream>
#include <time.h>
class Water
{
private:
    int width;
    int height;
    std::vector<glm::vec3> points;  //triangle mesh
    std::vector<glm::vec3> normals;
    //glm::mat4 boundaries;
    glm::mat4 model;
    glm::vec3 color;
    GLuint vao;
    GLuint vbos[2];
    GLuint cubemapTexture;
    GLuint underwaterTexture;
    std::string textureFile = "stone3.ppm";
    //get timestamp to compute sin function in shader
    //GLuint64 timestamp;
    //GLuint queryID;
    int textureWidth = 256;
    int textureHeight = 256;
    
public:
    Water(int width, int height, glm::mat4 model, GLuint cubemapTexture);
    ~Water();
    glm::mat4 getModel(){return model;};
    void update();

    void draw(GLuint Program, bool hasWave);
    unsigned char* loadPPM(const char* filename, int& width, int& height);
    int loadTexture();

};
#endif /* Water_hpp */

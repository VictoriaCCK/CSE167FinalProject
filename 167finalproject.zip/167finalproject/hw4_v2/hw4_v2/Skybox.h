//
//  Skybox.h
//  CSE167HW0_Shihui
//
//  Created by 吴诗慧 on 2020/2/24.
//  Copyright © 2020年 SelenaWu. All rights reserved.
//

#ifndef Skybox_h
#define Skybox_h

#ifdef __APPLE__
#include <OpenGL/gl3.h>
#else
#include <GL/glew.h>
#endif

#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <vector>
#include <stdlib.h>
#include <string>
#include <math.h>   // include math functions, such as sin, cos, M_PI
#include "Object.h"

class Skybox
{
private:
    GLuint vao;
    GLuint vbo[2];
    GLuint cubemapTexture;
    std::vector<std::string> faces =
    {"skybox/skybox1_px.ppm",
     "skybox/skybox1_nx.ppm",
     "skybox/skybox1_py.ppm",
     "skybox/skybox1_ny.ppm",
     "skybox/skybox1_pz.ppm",
     "skybox/skybox1_nz.ppm",
    };
//    std::vector<std::string> faces =
//    {"skybox/Skybox_Water222_right.ppm",
//        "skybox/Skybox_Water222_left.ppm",
//        "skybox/Skybox_Water222_top.ppm",
//        "skybox/Skybox_Water222_base.ppm",
//        "skybox/Skybox_Water222_front.ppm",
//        "skybox/Skybox_Water222_back.ppm",
//    };
    glm::mat4 model = glm::mat4(1.0f);
    
public:
    Skybox();
    ~Skybox();
    
    GLuint getCubemapTexture(){return cubemapTexture;};
    void draw();
    void update();
    glm::mat4 getModel(){return model;};
    unsigned char* loadPPM(const char* filename, int& width, int& height);
    int loadTexture();
};

#endif

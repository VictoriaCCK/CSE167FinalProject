//
//  NaiveModel.cpp
//  hw4
//
//  Created by Yaosen Lin on 3/9/20.
//  Copyright © 2020 YaosenLin. All rights reserved.
//

#include "NaiveModel.hpp"

NaiveModel::NaiveModel(string filename) {
    this->filename = filename;
    model = glm::mat4(1);
    load_mtl();
    load_mesh();
    setup_mesh();
}

void NaiveModel::load_mtl() {
    float r, g, b;
    int width, height, nc;
    string line;
    ifstream in(filename+".mtl");
    while(in) {
        getline(in, line);
        if(line.size()>0 && line[0]=='n' && line[1]=='e' && line[2]=='w') {
            Texture texture;
            texture.name = line.substr(7);
            
            getline(in, line);
            auto index0 = line.find(' ');
            auto index1 = line.find(' ', index0+1);
            auto index2 = line.find(' ', index1+2);
            r = stof(line.substr(index0+1, index1-index0-1));
            g = stof(line.substr(index1+1, index2-index1-1));
            b = stof(line.substr(index2+1));
            texture.ka = {r, g, b};
            
            getline(in, line);
            index0 = line.find(' ');
            index1 = line.find(' ', index0+1);
            index2 = line.find(' ', index1+2);
            r = stof(line.substr(index0+1, index1-index0-1));
            g = stof(line.substr(index1+1, index2-index1-1));
            b = stof(line.substr(index2+1));
            texture.kd = {r, g, b};
            
            getline(in, line);
            index0 = line.find(' ');
            index1 = line.find(' ', index0+1);
            index2 = line.find(' ', index1+2);
            r = stof(line.substr(index0+1, index1-index0-1));
            g = stof(line.substr(index1+1, index2-index1-1));
            b = stof(line.substr(index2+1));
            texture.ks = {r, g, b};
            
            getline(in, line);
            if(line.size()>0 && line[0]!='n') {
                texture.is_map = true;
//                line = line.substr(7);
//                glGenTextures(1, &texture.id);
//                glBindTexture(GL_TEXTURE_2D, texture.id);
//
//                glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
//                glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
//
//                glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
//                glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
//
//                unsigned char *data = stbi_load(line.c_str(), &width, &height, &nc, 0);
//                if (data) {
//                    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
//                    glGenerateMipmap(GL_TEXTURE_2D);
//                } else {
//                    std::cout << "Failed to load texture" << std::endl;
//                }
//                stbi_image_free(data);
            } else {
                texture.is_map = false;
            }
            textures.push_back(texture);
        } else {
            continue;
        }
    }
}

void NaiveModel::load_mesh() {
    vector<glm::vec3> v;
    vector<glm::vec2> vt;
    vector<glm::vec3> vn;
    
    float vx, vy, vz;
    float nx, ny, nz;
    float ts, tt;
    char c1 = 's', c2 = 's', c = 's';
    
    FILE *fp;
    string filename = this->filename+".obj";
    fp = fopen(filename.c_str(), "rb");
    
    if(!fp) {
        std::cerr<<"ERROR While Loading File"<<std::endl;
        perror("ERROR:");
    } else {
        while(c1!=EOF && c2!=EOF) {
            c1 = fgetc(fp);
            if(c1 == '\n') { continue; }
            c2 = fgetc(fp);
            if(c1=='v' and c2==' ') {
                fscanf(fp, "%f %f %f", &vx, &vy, &vz);
                v.push_back({vx, vy, vz});
            } else if(c1=='v' and c2=='n') {
                fscanf(fp, "%f %f %f", &nx, &ny, &nz);
                vn.push_back({nx, ny, nz});
            } else if(c1=='v' and c2=='t') {
                fscanf(fp, "%f %f", &ts, &tt);
                vt.push_back({ts, tt});
            } else {
                continue;
            }
        }
    }
    // cout<<"STEP 1, Loading All vertices, normals, textel coordinates with "<<v.size()<<" "<<vt.size()<<" "<<vn.size()<<endl;;

    
    
    int v1_id, v2_id, v3_id;
    int n1_id, n2_id, n3_id;
    int t1_id, t2_id, t3_id;
    glm::vec3 v1, v2, v3;
    glm::vec3 n1, n2, n3;
    glm::vec2 t1, t2, t3;
    c1 = 's';
    c2 = 's';
    
    fp = fopen(filename.c_str(), "rb");
    if(!fp) {
        std::cerr<<"ERROR While Loading File"<<std::endl;
        perror("ERROR:");
    } else {
        int cnt = -1;
        int idx = -1;
        while(c1!=EOF && c2!=EOF) {
            c1 = fgetc(fp);
            if(c1 == '\n') { continue; }
            c2 = fgetc(fp);
            if(c1=='u' and c2=='s') {
                Mesh current_mesh;
                string name;
                c = 's';
                while(c!=' ') {
                    c = fgetc(fp);
                }
                while(c!='\n') {
                    c = fgetc(fp);
                    name.push_back(c);
                }
                name = name.substr(0, name.size()-1);
                for(int i=0; i<textures.size(); ++i) {
                    if(textures[i].name == name) {
                        current_mesh.texture_id = i;
                        break;
                    }
                }
                meshes.push_back(current_mesh);
                cnt+=1;
                idx=-1;
            } else if(c1=='f' and c2==' ') {
                fscanf(fp, "%u/%u/%u %u/%u/%u %u/%u/%u", &v1_id, &t1_id, &n1_id, &v2_id, &t2_id, &n2_id, &v3_id, &t3_id, &n3_id);
                v1 = v[v1_id-1];
                v2 = v[v2_id-1];
                v3 = v[v3_id-1];
                meshes[cnt].vertices.push_back(v1);
                meshes[cnt].vertices.push_back(v2);
                meshes[cnt].vertices.push_back(v3);
                n1 = vn[n1_id-1];
                n2 = vn[n2_id-1];
                n3 = vn[n3_id-1];
                meshes[cnt].normals.push_back(n1);
                meshes[cnt].normals.push_back(n2);
                meshes[cnt].normals.push_back(n3);
                t1 = vt[t1_id-1];
                t2 = vt[t2_id-1];
                t3 = vt[t3_id-1];
                meshes[cnt].TexCoords.push_back(t1);
                meshes[cnt].TexCoords.push_back(t2);
                meshes[cnt].TexCoords.push_back(t3);
                
                meshes[cnt].indices.push_back({idx+1, idx+2, idx+3});
                idx += 3;
            } else { }
        }
    }
    //cout<<"STEP 2, Build Meshes with "<<meshes.size()<<endl;;
}

void NaiveModel::setup_mesh() {
    for(auto &mesh : meshes) {
        glGenVertexArrays(1, &mesh.VAO);
        glGenBuffers(1, &mesh.VBO);
        
        glBindVertexArray(mesh.VAO);
        glBindBuffer(GL_ARRAY_BUFFER, mesh.VBO);
        
        glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec3) * mesh.vertices.size(), mesh.vertices.data(), GL_STATIC_DRAW);
        
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), 0);
        
        glGenBuffers(1, &mesh.VBO);
        glBindVertexArray(mesh.VAO);
        glBindBuffer(GL_ARRAY_BUFFER, mesh.VBO);
        glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec3) * mesh.normals.size(), mesh.normals.data(), GL_STATIC_DRAW);
        glEnableVertexAttribArray(1);
        glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), 0);
        
//        glGenBuffers(1, &mesh.VBO);
//        glBindVertexArray(mesh.VAO);
//        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.VBO);
//        glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(glm::uvec2) * mesh.TexCoords.size(), mesh.TexCoords.data(), GL_STATIC_DRAW);
//        glEnableVertexAttribArray(2);
//        glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), 0);
        
        glGenBuffers(1, &mesh.EBO);
        glBindVertexArray(mesh.VAO);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.EBO);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(glm::uvec3)*mesh.indices.size(), mesh.indices.data(), GL_STATIC_DRAW);
        glEnableVertexAttribArray(3);
        glVertexAttribPointer(3, 3, GL_UNSIGNED_INT, GL_FALSE, 3 * sizeof(GL_UNSIGNED_INT), 0);
        
        glBindBuffer(GL_ARRAY_BUFFER, 0);
        glBindVertexArray(0);
    }
}

void NaiveModel::draw(GLuint shader) {
    for(auto mesh : meshes) {
        glUseProgram(shader);
        GLuint KaLoc = glGetUniformLocation(shader, "Ka");
        GLuint KdLoc = glGetUniformLocation(shader, "Kd");
        GLuint KsLoc = glGetUniformLocation(shader, "Ks");
        glm::vec3 Ka = textures[mesh.texture_id].ka;
        glUniform3fv(KaLoc, 1, glm::value_ptr(Ka));
        glm::vec3 Kd = textures[mesh.texture_id].kd;
        glUniform3fv(KdLoc, 1, glm::value_ptr(Kd));
        glm::vec3 Ks = textures[mesh.texture_id].ks;
        glUniform3fv(KsLoc, 1, glm::value_ptr(Ks));

        glBindVertexArray(mesh.VAO);
        glDrawElements(GL_TRIANGLES, mesh.indices.size()*3, GL_UNSIGNED_INT, 0);
        glBindVertexArray(0);
    }
}

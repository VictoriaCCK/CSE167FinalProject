//
//  Terrain.hpp
//  hw4_v2
//
//  Created by Yaosen Lin on 3/15/20.
//  Copyright © 2020 YaosenLin. All rights reserved.
//

#ifndef Terrain_hpp
#define Terrain_hpp

#ifdef __APPLE__
#include <OpenGL/gl3.h>
#else
#include <GL/glew.h>
#endif
#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtx/transform.hpp>

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <math.h>
#include <chrono>
#include <ctime>
#include <random>
using namespace std;

class Terrain {
public:
    int size;
    vector<vector<glm::vec2>> position;
    vector<vector<float>> height;
    float max_height=0.0f;
    float x_limit = 10.0f;
    float y_limit = 10.0f;
    bool first = true;
    
    glm::mat4 model;
    vector<glm::vec3> vertices;
    vector<glm::vec3> normals;
    vector<glm::uvec3> indices;
    vector<glm::vec2> texture_coordinates;
    GLuint VAO, VBO, EBO;
    int texture_width, texture_height, texture_nc;
    GLuint texture_id;
    
    Terrain(int n, float a=0.0, float b=0.0, float c=0.0, float d=0.0);
    
    void diamond_square(int stride);
    void square_step(int x, int y, int step);
    void diamond_step(int x, int y, int step);
    
    
    //chrono::high_resolution_clock::time_point = chrono::high_resolution_clock::now();
    
    std::random_device rd{};
    std::mt19937 generator{rd()};
    
    normal_distribution<double> noise{0.1,0.01};
    normal_distribution<double> noise_apex{1, 0.5};
    
    void build_terrain();
    void setup_terrain();
    void draw();
    
    void regenerate();
};

#endif /* Terrain_hpp */

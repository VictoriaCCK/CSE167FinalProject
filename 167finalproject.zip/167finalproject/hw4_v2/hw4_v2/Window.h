#ifndef _WINDOW_H_
#define _WINDOW_H_

#ifdef __APPLE__
#define GLFW_INCLUDE_GLCOREARB
#include <OpenGL/gl3.h>
#else
#include <GL/glew.h>
#endif

#include <GLFW/glfw3.h>

#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <iostream>
#include <vector>
#include <string>
#include <memory>

#include "shader.h"
#include "Object.h"
#include "Cube.h"
#include "Camera.hpp"
#include "NaiveModel.hpp"
#include "Terrain.hpp"
#include "Skybox.h"
#include "Particle.hpp"
#include "Water.hpp"
#include "Boundary.hpp"
#include "Floor.hpp"
#include "Creature.hpp"
#include "Grammar.hpp"
#include "LSystem.hpp"
#include "Trunks.hpp"


class Window
{
public:
	static bool initializeProgram();
	static bool initializeObjects();
	static void cleanUp();
	static GLFWwindow* createWindow(int width, int height);
	static void resizeCallback(GLFWwindow* window, int width, int height);
	static void idleCallback();
	static void displayCallback(GLFWwindow*);
	static void keyCallback(GLFWwindow* window, int key, int scancode, int action, int mods);
    
    // 063's function
    static void mouse_callback(GLFWwindow* window, double xpos, double ypos);
    
    //Shihui's function
    //functions for snow
    static bool initializeSnowProgram();
    static void initializeSnow();
    static void displaySnow();
    //functions for water
    static bool initializeWaterProgram();
    static void initializeWater();
    static void displayWater();
    //functions for skybox
    static bool initializeSkyboxProgram();
    static void initializeSkybox();
    static void displaySkybox();
    //functions for floor
    static bool initializeFloorProgram();
    static void initializeFloor();
    static void displayFloor();
    
    //Zijun's functions
    static bool initialGuider();
    static bool initialTree();
    static void displayGuider();
    static void displayTree(int c);
};

#endif

//
//  TerrainHelper.hpp
//  CSE167_group_proj
//
//  Created by 吴诗慧 on 2020/3/13.
//  Copyright © 2020年 SelenaWu. All rights reserved.
//

#ifndef TerrainHelper_hpp
#define TerrainHelper_hpp

#ifdef __APPLE__
#include <OpenGL/gl3.h>
#else
#include <GL/glew.h>
#endif

#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <vector>
#include <glm/gtc/type_ptr.hpp>
#include "Object.h"
#include <stdio.h>
#include <string.h>
#include <vector>
#include <iostream>

class Boundary
{
private:
    std::vector<glm::vec3> points;
    std::vector<glm::vec3> normals;
    std::vector<GLuint> indices;
    GLuint vao;
    GLuint vbo[2];
    GLuint ebo;
    std::string name;
    glm::mat4 model;
    
public:
    Boundary(std::string name, glm::mat4 model); //load obj
    ~Boundary();
    
    glm::mat4 getModel() { return model; }
    void setModel(glm::mat4 newModel) { model = newModel;}
    void draw();
    
};
#endif /* TerrainHelper_hpp */

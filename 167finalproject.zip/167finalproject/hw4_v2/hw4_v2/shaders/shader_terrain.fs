#version 330 core

uniform vec3 color;
uniform sampler2D TEXTURE;

in vec3 normal_color;
in vec2 TexCoord;
out vec4 FragColor;


void main() {
    vec3 NormalColor = normal_color;
    FragColor = texture(TEXTURE, TexCoord);
    
    //FragColor = mix(texture(TEXTURE, TexCoord),vec4(normal_color,0.5f),0.5);
}

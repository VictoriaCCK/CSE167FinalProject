#version 330 core

uniform vec3 Ka;
uniform vec3 Kd;
uniform vec3 Ks;
in vec3 normal_color;
out vec4 FragColor;

void main() {
    vec3 t0 = normal_color;
    FragColor = vec4(Kd, 1.0f);
}


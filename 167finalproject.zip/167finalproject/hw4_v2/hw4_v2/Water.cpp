//
//  Water.cpp
//  CSE167_group_proj
//
//  Created by 吴诗慧 on 2020/3/12.
//  Copyright © 2020年 SelenaWu. All rights reserved.
//

#include "Water.hpp"
Water::Water(int width_, int height_, glm::mat4 model_, GLuint cubemapTexture_){
    width = width_;
    height = height_;
    cubemapTexture = cubemapTexture_;
    //glGenQueries(1, &queryID);
    //glBeginQuery(GL_TIME_ELAPSED, queryID);
    //unsigned char disMap_[width+1 * height+1 * 3];
    //memset(disMap_, 0, sizeof(unsigned char)*(width+1) * (height+1) * 3);
    model =  model_;

    //construct a mesh
    for (int i = 0; i < width; i++){
        for (int j =0; j < height; j++){
            //a triangle
            points.push_back(glm::vec3(i, 0,j+1));
            normals.push_back(glm::vec3(0, 1, 0));
            points.push_back(glm::vec3(i, 0, j));
            normals.push_back(glm::vec3(0, 1, 0));
            points.push_back(glm::vec3(i+1, 0, j+1));
            normals.push_back(glm::vec3(0, 1, 0));
            //another triangle
            points.push_back(glm::vec3(i+1, 0, j+1));
            normals.push_back(glm::vec3(0, 1, 0));
            points.push_back(glm::vec3(i, 0, j));
            normals.push_back(glm::vec3(0, 1, 0));
            points.push_back(glm::vec3(i+1, 0, j));
            normals.push_back(glm::vec3(0, 1, 0));
        }
    }

    std::cout<<"triangles number"<<(points.size()/3)<<std::endl;
    // Generate a vertex array (VAO) and two vertex buffer objects (VBO).
    
    glGenVertexArrays(1, &vao);
    glGenBuffers(2, vbos);
    // Bind to the VAO.
    glBindVertexArray(vao);
    underwaterTexture = loadTexture();
    if (underwaterTexture != -1){
        std::cout<<"successfully load the underwater texture"<<std::endl;
    }
    // Bind to the first VBO. We will use it to store the vertices.
    glBindBuffer(GL_ARRAY_BUFFER, vbos[0]);
    // Pass in the data.
    glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec3) * points.size(),
                 points.data(), GL_STATIC_DRAW);
    // Enable vertex attribute 0.
    // We will be able to access vertices through it.
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), 0);
    
    // Unbind from the VBOs.
    glBindBuffer(GL_ARRAY_BUFFER, 0);

    glBindBuffer(GL_ARRAY_BUFFER, vbos[1]);
    // Pass in the data.
    glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec3) * normals.size(),
                 normals.data(), GL_STATIC_DRAW);
    // Enable vertex attribute 0.
    // We will be able to access vertices through it.
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), 0);
    // Unbind from the VBO.
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    // Unbind from the VAO.
    glBindVertexArray(0);
}

void Water::update(){
    //calculate the position
}
void Water::draw(GLuint program, bool hasWave){
    // Bind to the VAO.
    glBindVertexArray(vao);
    //std::cout<<"draw water"<<std::endl;
    //pass in uniform variables
    GLuint skyboxTexLoc = glGetUniformLocation(program, "skybox");
    GLuint underwaterTexLoc = glGetUniformLocation(program, "underwater");
    GLuint maxCoordLoc = glGetUniformLocation(program, "maxCoord");
    GLuint timeLoc = glGetUniformLocation(program, "time");
    GLuint waveLoc = glGetUniformLocation(program, "wave");
    //timestamp
    clock_t time = clock();
    glUniform1f(timeLoc, time/50000.0);
    glUniform1f(maxCoordLoc, fmax(width, height));
    glUniform1f(waveLoc, hasWave);
    
    //using multiple textures
    //https://stackoverflow.com/questions/25252512/how-can-i-pass-multiple-textures-to-a-single-shader
    //bind the textures
    glUniform1i(skyboxTexLoc, 0);
    glUniform1i(underwaterTexLoc,  1);
    glActiveTexture(GL_TEXTURE0 + 1);
    glBindTexture(GL_TEXTURE_2D, underwaterTexture);
    glActiveTexture(GL_TEXTURE0 + 0);
    glBindTexture(GL_TEXTURE_CUBE_MAP, cubemapTexture);
    //wireframe mode
    //glPolygonMode( GL_FRONT_AND_BACK, GL_LINE);
    // draw points
    glDrawArrays(GL_TRIANGLES, 0, points.size());
    //unbind texture
    glBindTexture(GL_TEXTURE_CUBE_MAP, 0);
    glBindTexture(GL_TEXTURE_2D, 0);
    //glPolygonMode( GL_FRONT_AND_BACK, GL_FILL );
    // Unbind from the VAO.
    glBindVertexArray(0);
}

Water::~Water(){
    glDeleteBuffers(2, vbos);
    glDeleteVertexArrays(1, &vao);
}

unsigned char* Water::loadPPM(const char* filename, int& width, int& height)
{
    const int BUFSIZE = 128;
    FILE* fp;
    unsigned int read;
    unsigned char* rawData;
    char buf[3][BUFSIZE];
    char* retval_fgets;
    size_t retval_sscanf;
    
    if ( (fp=fopen(filename, "rb")) == NULL)
    {
        std::cerr << "error reading ppm file, could not locate " << filename << std::endl;
        width = 0;
        height = 0;
        return NULL;
    }
    
    // Read magic number:
    retval_fgets = fgets(buf[0], BUFSIZE, fp);
    
    // Read width and height:
    do
    {
        retval_fgets=fgets(buf[0], BUFSIZE, fp);
    } while (buf[0][0] == '#');
    retval_sscanf=sscanf(buf[0], "%s %s", buf[1], buf[2]);
    width  = atoi(buf[1]);
    height = atoi(buf[2]);
    
    // Read maxval:
    do
    {
        retval_fgets=fgets(buf[0], BUFSIZE, fp);
    } while (buf[0][0] == '#');
    
    // Read image data:
    rawData = new unsigned char[width * height * 3];
    read = fread(rawData, width * height * 3, 1, fp);
    fclose(fp);
    if (read != 1)
    {
        std::cerr << "error parsing ppm file, incomplete data" << std::endl;
        delete[] rawData;
        width = 0;
        height = 0;
        return NULL;
    }
    
    return rawData;
}

int Water::loadTexture()
{
    GLuint texture[1];     // storage for one texture
    int twidth = textureWidth;
    int theight = textureHeight;   // texture width/height [pixels]
    unsigned char* tdata;  // texture pixel data
    
    // Load image file
    tdata = loadPPM(textureFile.c_str(), twidth, theight);
    if (tdata==NULL) return -1;
    
    // Create ID for texture
    glGenTextures(1, &texture[0]);
    
    // Set this texture to be the one we are working with
    glBindTexture(GL_TEXTURE_2D, texture[0]);
    // Set bi-linear filtering for both minification and magnification
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    // Generate the texture
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, twidth, theight, 0, GL_RGB, GL_UNSIGNED_BYTE, tdata);
    //glTexImage2D(GL_TEXTURE_2D, 0, 3, twidth, theight, 0, GL_RGB, GL_UNSIGNED_BYTE, tdata);
    glBindTexture(GL_TEXTURE_2D, 0);
    

    return texture[0];
}

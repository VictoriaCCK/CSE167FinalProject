#include "Window.h"

/* 
 * Declare your variables below. Unnamed namespace is used here to avoid 
 * declaring global or static variables.
 */
namespace
{
	int width, height;
	std::string windowTitle("CSE167");

	Cube* cube;
    Object* currentObj; // The object currently displaying.

    //063's variables start
    glm::vec3 camera_position(0, 8, 120); // Camera position.
    glm::vec3 camera_front(0, 0, -20); // the direction that the camera look at
    glm::vec3 camera_up(0, 1, 0);
    float fovy = 60;
    float near = 1;
    float far = 1000;

    Camera* camera = new Camera(camera_position, camera_front, camera_up);
    glm::mat4 view = camera->GetViewMatrix();

    float last_frame_time = 0;
    bool is_moving = false;
    Camera_Movement camera_movement_direction;

    vector<NaiveModel*> scene;
    NaiveModel *my_model;
    GLuint program_model; // The shader program id.
    GLuint projectionLoc_model; // Location of projection in shader.
    GLuint viewLoc_model; // Location of view in shader.
    GLuint modelLoc_model; // Location of model in shader

    double last_cursor_x = 0;
    double last_cursor_y = 0;
    bool look_around = false;

    Terrain* mountain;
    GLuint program_terrain; // The shader program id.
    GLuint projectionLoc_terrain; // Location of projection in shader.
    GLuint viewLoc_terrain; // Location of view in shader.
    GLuint modelLoc_terrain; // Location of model in shader
    GLuint colorLoc_terrain;
    //063's variables end
    
    //Shihui's vaeriable
    //Shihui - snow particle effect
    GLuint program_snow;
    GLuint projectionLoc_snow; // Location of projection in shader.
    GLuint viewLoc_snow; // Location of view in shader.
    GLuint modelLoc_snow; // Location of model in shader.
    GLuint colorLoc_snow; // Location of color in shader.
    GLuint cameraPosLoc_snow;
    std::vector<Particle*> snowContainer;
    int snowNum = 200;
    bool hasSnow = false;
    
    //Shihui - water
    GLuint program_water;
    GLuint projectionLoc_water; // Location of projection in shader.
    GLuint viewLoc_water; // Location of view in shader.
    GLuint modelLoc_water; // Location of model in shader.
    GLuint colorLoc_water; // Location of color in shader.
    GLuint cameraPosLoc_water;
    bool hasWave = false;
    int water_width = 20;
    int water_height = 20;
    int water_xoffset = 0;
    int water_yoffset = 1.0;
    int water_zoffset = 40;
    Water* pond;
    
    //SHihui- water boundary
    Boundary* boundary;
    GLuint program_boundary;
    GLuint projectionLoc_boundary;
    GLuint viewLoc_boundary;
    GLuint modelLoc_boundary;
    
    //Shihui- skybox
    Skybox* skybox;
    GLuint program_skybox;
    GLuint projectionLoc_skybox;
    GLuint viewLoc_skybox;
    GLuint modelLoc_skybox;
    GLuint colorLoc_skybox;
    GLuint cubemapTexture;
    
    //SHihui - floor
    Floor* my_floor;
    GLuint program_floor;
    GLuint modelLoc_floor;
    GLuint viewLoc_floor;
    GLuint projectionLoc_floor;
    //Shiuhi's variable end
    
    //Zijun's variables
    //glm::vec3 eye = glm::vec3(10.f, 0.f ,20.f);
    Creature* guider;
    Creature* guider2;
    vector<FractalSystem*> forest;
    FractalSystem* tree;
    Trunks* t;
    vector<Trunks*> ts;
    int c = 0;// count of trees
    
    GLuint program; // The shader program id.
    GLuint projectionLoc; // Location of projection in shader.
    GLuint viewLoc; // Location of view in shader.
    GLuint modelLoc; // Location of model in shader.
    GLuint colorLoc; // Location of color in shader.
    
    GLuint programGuider; // The shader program id.
    GLuint projectionLocGuider; // Location of projection in shader.
    GLuint viewLocGuider; // Location of view in shader.
    GLuint modelLocGuider; // Location of model in shader.
    GLuint colorLocGuider; // Location of color in shader.
    GLuint eyeLocGuider;
    GLuint specularLocGuider;
    GLuint diffuseLocGuider;
    GLuint ambientLocGuider;

	glm::mat4 projection; // Projection matrix.

};

void construct_scene() {
    my_model = new NaiveModel("Chinese+architecture_02/Chinese+architecture_02");
    my_model->model = glm::translate(glm::mat4(1.0f), glm::vec3(-10, 0, 0))* glm::scale(glm::vec3(0.015f, 0.015f, 0.015f));
    scene.push_back(my_model);
    my_model = new NaiveModel("pagoda/pagoda");
    my_model -> model = glm::translate(glm::mat4(1.0f), glm::vec3(-35, 0,20))* glm::scale(glm::vec3(0.3f, 0.3f, 0.3f));
    scene.push_back(my_model);
    my_model = new NaiveModel("gongdian/gongdian");
    my_model -> model = glm::translate(glm::mat4(1.0f), glm::vec3(-30, 0, 55))*glm::scale(glm::vec3(0.5f, 0.5f, 0.5f));
    scene.push_back(my_model);
    my_model = new NaiveModel("yuanzi/yuanzi");
    my_model->model = glm::translate(glm::mat4(1.0f), glm::vec3(30, 0, 45))* glm::scale(glm::vec3(-0.02f, 0.02f,0.02f));
    scene.push_back(my_model);
}

bool initialize_063_program() {
    program_model = LoadShaders("shaders/shader_model.vs", "shaders/shader_model.fs");
    if (!program_model) {
        std::cerr << "Failed to initialize shader program" << std::endl;
        return false;
    }
    
    program_terrain = LoadShaders("shaders/shader_terrain.vs", "shaders/shader_terrain.fs");
    if (!program_terrain) {
        std::cerr << "Failed to initialize shader program" << std::endl;
        return false;
    }
    
    // 063, gets the locations of uniform variables
    glUseProgram(program_model);
    projectionLoc_model = glGetUniformLocation(program_model, "projection");
    viewLoc_model = glGetUniformLocation(program_model, "view");
    modelLoc_model = glGetUniformLocation(program_model, "model");
    
    glUseProgram(program_terrain);
    projectionLoc_terrain = glGetUniformLocation(program_terrain, "projection");
    viewLoc_terrain = glGetUniformLocation(program_terrain, "view");
    modelLoc_terrain = glGetUniformLocation(program_terrain, "model");
    colorLoc_terrain = glGetUniformLocation(program_terrain, "color");
    
    return true;
}

void display_model() {}

void display_terrain() {}


bool Window::initializeProgram() {
    // 063's program initialization starts
    initialize_063_program();
    
    //Shihui's shader programs
    initializeSnowProgram();
    initializeWaterProgram();
    initializeSkyboxProgram();
    initializeFloorProgram();
    
    //Zijun's shader programs (and objects !)
    if(initialTree() == false) return false;
    if(initialGuider() == false) return false;
    
    return true;
}

bool Window::initializeSnowProgram(){
    // Create a shader program with a vertex shader and a fragment shader.
    program_snow = LoadShaders("shaders/shader_snow.vert", "shaders/shader_snow.frag");
    // Check the shader program.
    if (!program_snow)
    {
        std::cerr << "Failed to initialize snow shader program" << std::endl;
        return false;
    }
    projectionLoc_snow = glGetUniformLocation(program_snow, "projection");
    viewLoc_snow = glGetUniformLocation(program_snow, "view");
    modelLoc_snow = glGetUniformLocation(program_snow, "model");
    colorLoc_snow = glGetUniformLocation(program_snow, "color");
    cameraPosLoc_snow = glGetUniformLocation(program_snow, "cameraPos");
    return true;
}

bool Window::initializeWaterProgram(){
    // Create a shader program with a vertex shader and a fragment shader.
    program_water = LoadShaders("shaders/shader_water.vert", "shaders/shader_water.frag");
    // Check the shader program.
    if (!program_water)
    {
        std::cerr << "Failed to initialize water shader program" << std::endl;
        return false;
    }
    projectionLoc_water = glGetUniformLocation(program_water, "projection");
    viewLoc_water = glGetUniformLocation(program_water, "view");
    modelLoc_water = glGetUniformLocation(program_water, "model");
    colorLoc_water = glGetUniformLocation(program_water, "color");
    cameraPosLoc_water = glGetUniformLocation(program_water, "cameraPos");
    
    
    program_boundary = LoadShaders("shaders/shader_boundary.vert", "shaders/shader_boundary.frag");
    // Check the shader program.
    if (!program_boundary)
    {
        std::cerr << "Failed to initialize water boundary shader program" << std::endl;
        return false;
    }
    projectionLoc_boundary = glGetUniformLocation(program_boundary, "projection");
    viewLoc_boundary = glGetUniformLocation(program_boundary, "view");
    modelLoc_boundary = glGetUniformLocation(program_boundary, "model");
    return true;
}

bool Window::initializeFloorProgram(){
    //Shihui - floor
    program_floor = LoadShaders("shaders/shader_floor.vert", "shaders/shader_floor.frag");
    if (! program_floor) {
        std::cerr << "Failed to initialize floor shader program" << std::endl;
        return false;
    }
    glUseProgram(program_floor);
    modelLoc_floor = glGetUniformLocation(program_floor, "model");
    viewLoc_floor = glGetUniformLocation(program_floor, "view");
    projectionLoc_floor = glGetUniformLocation(program_floor, "projection");
    return true;
}

bool Window::initializeSkyboxProgram(){
    // Create a shader program with a vertex shader and a fragment shader.
    program_skybox = LoadShaders("shaders/shader_skybox.vert", "shaders/shader_skybox.frag");
    // Check the shader program.
    if (!program_skybox)
    {
        std::cerr << "Failed to initialize skybox shader program" << std::endl;
        return false;
    }
    projectionLoc_skybox = glGetUniformLocation(program_skybox, "projection");
    viewLoc_skybox = glGetUniformLocation(program_skybox, "view");
    modelLoc_skybox = glGetUniformLocation(program_skybox, "model");
    colorLoc_skybox = glGetUniformLocation(program_skybox, "color");
    return true;
}

bool Window::initialTree() {
    program = LoadShaders("shaders/shader.vert", "shaders/shader.frag");
    
    // Check the shader program.
    if (!program) {
        std::cerr << "Failed to initialize shader program" << std::endl;
        return false;
    }
    
    // Activate the shader program.
    glUseProgram(program);
    // Get the locations of uniform variables.
    projectionLoc = glGetUniformLocation(program, "projection");
    viewLoc = glGetUniformLocation(program, "view");
    modelLoc = glGetUniformLocation(program, "model");
    colorLoc = glGetUniformLocation(program, "color");
    for (int i = -5, z = 0; i<18 ; ) {
        tree = new FractalSystem(glm::vec3(i, 0.f ,z), glm::vec3(0.f, 1.f ,0.f));
        forest.push_back(tree);
        t = new Trunks(tree->trunks);
        ts.push_back(t);
        i += 11;
        z += 11;
    }
    return true;
}

bool Window::initialGuider() {
    programGuider = LoadShaders("shaders/toon shader.vert", "shaders/toon shader.frag");
    
    // Check the shader program.
    if (!programGuider) {
        std::cerr << "Failed to initialize shader program" << std::endl;
        return false;
    }
    
    // Activate the shader program.
    glUseProgram(programGuider);
    // Get the locations of uniform variables.
    projectionLocGuider = glGetUniformLocation(programGuider, "projection");
    viewLocGuider = glGetUniformLocation(programGuider, "view");
    modelLocGuider = glGetUniformLocation(programGuider, "model");
    colorLocGuider = glGetUniformLocation(programGuider, "color");
    eyeLocGuider = glGetUniformLocation(programGuider, "eye");
    specularLocGuider = glGetUniformLocation(programGuider, "specular");
    ambientLocGuider = glGetUniformLocation(programGuider, "ambient");
    diffuseLocGuider = glGetUniformLocation(programGuider, "diffuse");
    
    guider = new Creature("Avatar.obj", 3);
    guider2 = new Creature("Avatar.obj", 3);
    return true;
}

bool Window::initializeObjects() {
	// Create a cube of size 5.
	cube = new Cube(5.0f);
	// Set cube to be the first to display
	currentObj = cube;
    
    
    // 063's objects initialization
    construct_scene();
    mountain = new Terrain(5, 0.0f, 0.0f, 0.0f, 0.0f);
    mountain->build_terrain();
    mountain->setup_terrain();
    mountain->model = glm::translate(glm::vec3(-60.0f, 0.0f, -60.0f))*glm::scale(glm::vec3(4.0f, 4.0f, 4.f));
    
    
    //Shihui's objects
    initializeSkybox();
    initializeSnow();
    initializeWater();
    initializeFloor();
	return true;
}

void Window::initializeSnow(){
    for (int i = 0; i < snowNum; i ++){
        Particle* p = new Particle();
        snowContainer.push_back(p);
    }
}

void Window::initializeWater(){
    //TODO::modify to fit the screen
    int width = water_width;
    int height = water_height;
    glm::vec3 move = glm::vec3(-width/2 + water_xoffset, water_yoffset, -height/2 + water_zoffset);
    glm::mat4 model = glm::translate(glm::mat4(1.0f), move);
    pond = new Water(width, height, model, cubemapTexture);
    glUseProgram(program_water);
    glUniformMatrix4fv(modelLoc_water, 1, GL_FALSE, glm::value_ptr(model));
    
    //the water boundary
    glm::mat4 translateMatrix = glm::translate(glm::mat4(1.0f),glm::vec3(water_xoffset - 9, water_yoffset + 1 , water_zoffset - 9.5));
    glm::mat4 rotateMatrix = glm::rotate(glm::mat4(1.0f),glm::radians(-90.0f), glm::vec3(0.0f, 1.0f, 0.0f));
    glm::mat4 bdy_model = translateMatrix* rotateMatrix*glm::scale(glm::mat4(1.0f), glm::vec3(2.5f,1.25f,1.25f));
    boundary = new Boundary("pondBoundary.obj", bdy_model);
    //boundary = new Boundary("Avatar.obj", bdy_model);
    glUseProgram(program_boundary);
    glUniformMatrix4fv(modelLoc_boundary, 1, GL_FALSE, glm::value_ptr(bdy_model));
}

void Window::initializeSkybox(){
    skybox = new Skybox();
    cubemapTexture = skybox->getCubemapTexture();
}

void Window::initializeFloor(){
    my_floor = new Floor(120, 150);
    glUseProgram(program_floor);
    glUniformMatrix4fv(modelLoc_floor, 1, GL_FALSE, glm::value_ptr(glm::mat4(1.0f)));
}

void Window::cleanUp() {
	// Deallcoate the objects.
	delete cube;
    delete skybox;
    delete my_floor;
    delete pond;
    delete boundary;
    delete guider;
    delete t;
    delete tree;
    for (int i = 0; i < snowNum; i++){
        delete snowContainer[i];
    }
    delete mountain;
    delete camera;
	// Delete the shader program.
	glDeleteProgram(program_model);
    glDeleteProgram(program_terrain);
    glDeleteProgram(program_water);
    glDeleteProgram(program_skybox);
    glDeleteProgram(program_snow);
    glDeleteProgram(program_floor);
    glDeleteProgram(programGuider);
    glDeleteProgram(program);
}

GLFWwindow* Window::createWindow(int width, int height) {
	// Initialize GLFW.
	if (!glfwInit()) {
		std::cerr << "Failed to initialize GLFW" << std::endl;
		return NULL;
	}

	// 4x antialiasing.
	glfwWindowHint(GLFW_SAMPLES, 4);

#ifdef __APPLE__ 
	// Apple implements its own version of OpenGL and requires special treatments
	// to make it uses modern OpenGL.

	// Ensure that minimum OpenGL version is 3.3
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	// Enable forward compatibility and allow a modern OpenGL context
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

	// Create the GLFW window.
	GLFWwindow* window = glfwCreateWindow(width, height, windowTitle.c_str(), NULL, NULL);

	// Check if the window could not be created.
	if (!window) {
		std::cerr << "Failed to open GLFW window." << std::endl;
		glfwTerminate();
		return NULL;
	}
    
    // 063's setup
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// Make the context of the window.
	glfwMakeContextCurrent(window);

#ifndef __APPLE__
	// On Windows and Linux, we need GLEW to provide modern OpenGL functionality.
	// Initialize GLEW.
	if (glewInit()) {
		std::cerr << "Failed to initialize GLEW" << std::endl;
		return NULL;
	}
#endif

	// Set swap interval to 1.
	glfwSwapInterval(0);

	// Call the resize callback to make sure things get drawn immediately.
	Window::resizeCallback(window, width, height);

	return window;
}

void Window::resizeCallback(GLFWwindow* window, int w, int h) {
#ifdef __APPLE__
	// In case your Mac has a retina display.
	glfwGetFramebufferSize(window, &width, &height);
#endif
	width = w*2;
	height = h*2;
	// Set the viewport size.
	glViewport(0, 0, width, height);

	// Set the projection matrix.
	projection = glm::perspective(glm::radians(fovy), (float)width / (float)height, near, far);
    
    // 063 sets the first frame time
    last_frame_time = glfwGetTime();
}

void Window::idleCallback() {
	// Perform any updates as necessary. 
	currentObj->update();
    
    // 063 updates the camera's position and frame time
    if(is_moving) {
        camera->ProcessKeyboard(camera_movement_direction, glfwGetTime()-last_frame_time);
        view = camera->GetViewMatrix();
    }
    last_frame_time = glfwGetTime();
}

void Window::displayCallback(GLFWwindow* window) {
	// Clear the color and depth buffers.
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // 063's render
    glUseProgram(program_model);
    glm::mat4 model;
	glUniformMatrix4fv(projectionLoc_model, 1, GL_FALSE, glm::value_ptr(projection));
	glUniformMatrix4fv(viewLoc_model, 1, GL_FALSE, glm::value_ptr(view));
    for(int i=0; i<scene.size(); ++i) {
        my_model = scene[i];
        model = my_model->model;
        glUniformMatrix4fv(modelLoc_model, 1, GL_FALSE, glm::value_ptr(model));
        my_model->draw(program_model);
    }
    
    glUseProgram(program_terrain);
    model = mountain->model;
    glUniformMatrix4fv(projectionLoc_terrain, 1, GL_FALSE, glm::value_ptr(projection));
    glUniformMatrix4fv(viewLoc_terrain, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(modelLoc_terrain, 1, GL_FALSE, glm::value_ptr(model));
    mountain->draw();
    
    
    //SHihui's drawing function
    if (hasSnow){
        displaySnow();
    }
    displayWater();
    displaySkybox();
    displayFloor();
    
    //Zijun's drawing function
    for(int i = 0; i<c and i<forest.size(); i++){
        displayTree(i);
    }
    displayGuider();
	// Gets events, including input such as keyboard and mouse or window resizing.
	glfwPollEvents();
	// Swap buffers.
	glfwSwapBuffers(window);
}

void Window::displaySnow(){
    glUseProgram(program_snow);
    for (int i = 0; i < snowNum; i ++){
        snowContainer[i] -> update();
        glm::mat4 snowModel = snowContainer[i] -> getModel();
        glUniformMatrix4fv(projectionLoc_snow, 1, GL_FALSE, glm::value_ptr(projection));
        glUniformMatrix4fv(viewLoc_snow, 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(modelLoc_snow, 1, GL_FALSE, glm::value_ptr(snowModel));
        glUniform3fv(cameraPosLoc_snow, 1, glm::value_ptr(camera ->Position));
        snowContainer[i] -> draw();
    }
}

void Window::displayWater(){
    glUseProgram(program_water);
    pond->update();
    //glm::mat4 pondModel = pond -> getModel();
    //std::cout<<pondModel[3][0]<<" "<<pondModel[3][1]<<" "<<pondModel[3][2]<<std::endl;
    glUniformMatrix4fv(projectionLoc_water, 1, GL_FALSE, glm::value_ptr(projection));
    glUniformMatrix4fv(viewLoc_water, 1, GL_FALSE, glm::value_ptr(view));
    //glUniformMatrix4fv(modelLoc_water, 1, GL_FALSE, glm::value_ptr(pondModel));
    glUniform3fv(cameraPosLoc_water, 1, glm::value_ptr(camera ->Position));
    pond->draw(program_water, hasWave);
    //boundary
    glUseProgram(program_boundary);
    glUniformMatrix4fv(projectionLoc_boundary, 1, GL_FALSE, glm::value_ptr(projection));
    glUniformMatrix4fv(viewLoc_boundary, 1, GL_FALSE, glm::value_ptr(view));
    boundary -> draw();
}

void Window::displaySkybox(){
    glUseProgram(program_skybox);
    glm::mat4 model_skybox = skybox->getModel();
    glUniformMatrix4fv(modelLoc_skybox, 1, GL_FALSE, glm::value_ptr(model_skybox));
    glUniformMatrix4fv(projectionLoc_skybox, 1, GL_FALSE, glm::value_ptr(projection));
    glUniformMatrix4fv(viewLoc_skybox, 1, GL_FALSE, glm::value_ptr(view));
    skybox->draw();
}

void Window::displayFloor(){
    glUseProgram(program_floor);
    glUniformMatrix4fv(viewLoc_floor, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projectionLoc_floor, 1, GL_FALSE, glm::value_ptr(projection));
    my_floor -> draw();
}

void Window::displayTree(int idx)
{
    // Switch back to using OpenGL's rasterizer
    glUseProgram(program);
    // Clear the color and depth buffers.
    //    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    // Specify the values of the uniform variables we are going to use.
    /*
     * TODO: Section 3 and 4: Modify the code here to draw both the bunny and
     * the dragon
     * Note that the model matrix sent to the shader belongs only
     * to what object the currentObj ptr is pointing to. You will need to
     * use another call to glUniformMatrix4fv to change the model matrix
     * data being sent to the vertex shader before you draw the other object
     */
    glm::mat4 model = glm::mat4(1);
    glm::vec3 color = glm::vec3(0.f, 1.f, 0.f);
    glUniformMatrix4fv(projectionLoc, 1, GL_FALSE, glm::value_ptr(projection));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniform3fv(colorLoc, 1, glm::value_ptr(color));
    // Render the object.
    
    color = glm::vec3(0.13f, 0.55f, 0.13f);
    glUniform3fv(colorLoc, 1, glm::value_ptr(color));
    forest[idx]->draw();
    color = glm::vec3(0.50f, 0.16f, 0.16f);
    glUniform3fv(colorLoc, 1, glm::value_ptr(color));
    ts[idx]->draw();
}

void Window::displayGuider()
{
    // Switch back to using OpenGL's rasterizer
    glUseProgram(programGuider);
    // Clear the color and depth buffers.
    //tglClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    glm::mat4 model = guider->getModel();
 
    glm::vec3 color = guider->getColor();
    glUniformMatrix4fv(projectionLocGuider, 1, GL_FALSE, glm::value_ptr(projection));
    glUniformMatrix4fv(viewLocGuider, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(modelLocGuider, 1, GL_FALSE, glm::value_ptr(model));
    glUniform3fv(colorLocGuider, 1, glm::value_ptr(color));
    glUniform3fv(eyeLocGuider, 1, glm::value_ptr(camera->Position));
    glUniform3fv(ambientLocGuider, 1, glm::value_ptr(guider->ambient));
    glUniform3fv(specularLocGuider, 1, glm::value_ptr(guider->specular));
    glUniform3fv(diffuseLocGuider, 1, glm::value_ptr(guider->diffuse));
    // Render the object.
    guider->draw();
    model = guider2->getModel();
    model = glm::rotate(glm::mat4(1.0f),glm::radians(180.0f), glm::vec3(0.0f, 1.0f, 0.0f))*model;
    model = glm::translate(glm::mat4(1), glm::vec3(0.0f,0.0f,130.0f))*model;
    glUniformMatrix4fv(modelLocGuider, 1, GL_FALSE, glm::value_ptr(model));
    guider2->draw();
}

void Window::keyCallback(GLFWwindow* window, int key, int scancode, int action, int mods) {
	if (action == GLFW_PRESS) {
        switch (key) {
            case GLFW_KEY_ESCAPE: {
                glfwSetWindowShouldClose(window, GL_TRUE);
                break;
            }
            //Shihui's key control
            case GLFW_KEY_1: {
                //toggle water has wave/ does not has water
                hasWave = !hasWave;
                break;
            }
            case GLFW_KEY_2: {
                //toggle has/does not have snow
                hasSnow = !hasSnow;
                break;
            }
            case GLFW_KEY_T: {
                // draw tree
                if (c < forest.size()) c += 1;
                break;
            }
            case GLFW_KEY_W: {
                is_moving = true;
                camera_movement_direction = FORWARD;
                break;
            }
            case GLFW_KEY_S: {
                is_moving = true;
                camera_movement_direction = BACKWARD;
                break;
            }
            case GLFW_KEY_A: {
                is_moving = true;
                camera_movement_direction = LEFT;
                break;
            }
            case GLFW_KEY_D: {
                is_moving = true;
                camera_movement_direction = RIGHT;
                break;
            }
            case GLFW_KEY_Z: {
                is_moving = true;
                if(mods == GLFW_MOD_SHIFT) {
                    camera_movement_direction = HIGH;
                } else {
                    camera_movement_direction = LOW;
                }
            }
            case GLFW_KEY_0: {
                delete mountain;
                mountain = new Terrain(5, 0.0f, 0.0f, 0.0f, 0.0f);
                mountain->build_terrain();
                mountain->setup_terrain();
                mountain->model = glm::translate(glm::vec3(-60.0f, 0.0f, -60.0f))*glm::scale(glm::vec3(4.0f, 4.0f, 4.f));
                //mountain->regenerate();
                break;
            }
            default: {
                std::cout<< "KEYBOARD INPUT DOES NOT SET UP"<< std::endl;
                break;
            }
        }
    }
    
    if(action == GLFW_RELEASE) {
        switch (key) {
            case GLFW_KEY_W: {
                is_moving = false;
                camera_movement_direction = FORWARD;
                break;
            }
            case GLFW_KEY_S: {
                is_moving = false;
                camera_movement_direction = BACKWARD;
                break;
            }
            case GLFW_KEY_A: {
                is_moving = false;
                camera_movement_direction = LEFT;
                break;
            }
            case GLFW_KEY_D: {
                is_moving = false;
                camera_movement_direction = RIGHT;
                break;
            }
            case GLFW_KEY_Z: {
                is_moving = false;
            }
        }
    }
}

void Window::mouse_callback(GLFWwindow* window, double x, double y) {
    if(!look_around){
        look_around = true;
        last_cursor_x = x;
        last_cursor_y = y;
    } else {
        camera->ProcessMouseMovement(x-last_cursor_x, last_cursor_y-y);
        view = camera->GetViewMatrix();
        last_cursor_x = x;
        last_cursor_y = y;
    }
    
    
//    if(glfwGetMouseButton(window, 0)==GLFW_PRESS) {
//        if(!look_around){
//            look_around = true;
//            last_cursor_x = x;
//            last_cursor_y = y;
//        } else {
//            camera->ProcessMouseMovement(last_cursor_x-x, last_cursor_y-y);
//            view = camera->GetViewMatrix();
//            last_cursor_x = x;
//            last_cursor_y = y;
//        }
//    }
//    if(glfwGetMouseButton(window, 0)==GLFW_RELEASE) {
//        look_around = false;
//    }
}

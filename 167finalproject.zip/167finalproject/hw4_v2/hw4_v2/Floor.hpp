//
//  Floor.hpp
//  hw4_v2
//
//  Created by 吴诗慧 on 2020/3/17.
//  Copyright © 2020年 YaosenLin. All rights reserved.
//

#ifndef Floor_hpp
#define Floor_hpp

#ifdef __APPLE__
#include <OpenGL/gl3.h>
#else
#include <GL/glew.h>
#endif

#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <vector>

#include "Object.h"
#include <stdio.h>
#include <string.h>
#include <vector>
#include <iostream>
#include <time.h>

class Floor
{
private:
    int width;
    int height;
    std::vector<glm::vec3> points;  //triangle mesh
    std::vector<glm::vec2> texCoords;
    //glm::mat4 boundaries;
    glm::mat4 model;
    glm::vec3 color;
    GLuint vao;
    GLuint vbos[2];
    GLuint floorTexture;
    std::string textureFile = "floorTexture.ppm";
    int textureWidth = 1300;
    int textureHeight = 1300;
public:
    Floor(int width, int height);
    ~Floor();
    //glm::mat4 getModel(){return model;};
    //void update();
    
    void draw();
    unsigned char* loadPPM(const char* filename, int& width, int& height);
    int loadTexture();
    
};
#endif /* Floor_hpp */

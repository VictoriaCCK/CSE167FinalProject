//
//  Particle.hpp
//  CSE167_group_proj
//
//  Created by 吴诗慧 on 2020/3/9.
//  Copyright © 2020年 SelenaWu. All rights reserved.
//

#ifndef Particle_hpp
#define Particle_hpp
#ifdef __APPLE__
#include <OpenGL/gl3.h>
#else
#include <GL/glew.h>
#endif

#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <vector>

#include "Object.h"
#include <stdio.h>
#include <string.h>
#include <vector>
#include <iostream>
class Particle
{
private:
    float lifetime = 1;
    glm::vec3 pos;
    glm::vec3 initPos;
    glm::vec3 velocity;  //speed and direction
    float decay;
    glm::vec3 gravity = glm::vec3(0.0f,-9.8f*0.03, 0.0f);
    GLuint vao;
    GLuint vbo;
    glm::mat4 model = glm::mat4(1.0f);
    float alpha = 0.9f;
    float size;
    
public:
    Particle();
    ~Particle();
    glm::mat4 getModel(){return model;};
    glm::vec3 getPos(){return pos;};
    void update();
    //reuse the snow if dead
    void restore();
    void draw();
    glm::vec3 genRandomPoint();
    glm::vec3 genRandomVelocity();
};
#endif /* Particle_hpp */

//
//  Terrain.cpp
//  hw4_v2
//
//  Created by Yaosen Lin on 3/15/20.
//  Copyright © 2020 YaosenLin. All rights reserved.
//

#include "Terrain.hpp"
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

Terrain::Terrain(int n, float a, float b, float c, float d) {
    model = glm::mat4(1);
    size = pow(2, n) + 1;
    for(int i=0; i<size; ++i) {
        vector<float> h(size);
        height.push_back(h);
        vector<glm::vec2> element(size);
        position.push_back(element);
    }
    height[0][0] = a;
    height[0][size-1] = b;
    height[size-1][0] = c;
    height[size-1][size-1] = d;
    
    float r_x = x_limit / (size-1);
    float r_y = y_limit / (size-1);
    for(int i=0; i<size; ++i) {
        float x = i*r_x;
        for(int j=0; j<size; ++j) {
            float y = j*r_y;
            position[i][j]={x, y};
        }
    }
}

void Terrain::diamond_square(int stride) {
    int step = stride/ 2;
    if(first) {
        for(int y = step; y<size; y+=stride) {
            for(int x = step; x<size; x+=stride) {
                height[x][y] = 3.0f + noise_apex(generator);
            }
        }
        first = false;
    } else {
        int step = stride/ 2;
        for(int y = step; y<size; y+=stride) {
            for(int x = step; x<size; x+=stride) {
                if(x==0 || y==0 || x==size-1 || y==size-1) {
                    height[x][y] = 0;
                } else {
                    square_step(x, y, step);
                }
            }
        }
    }
    int column = 0;
    for(int x = 0; x<size; x+=step) {
        column++;
        if (column % 2 == 1) {
            for(int y=step; y<size; y+=stride) {
                if(x==0 || y==0 || x==size-1 || y==size-1) {
                    height[x][y] = 0;
                } else {
                    diamond_step(x, y, step);
                }
            }
        } else {
            for(int y=0; y<size; y+=stride) {
                if(x==0 || y==0 || x==size-1 || y==size-1) {
                    height[x][y] = 0;
                } else {
                    diamond_step(x, y, step);
                }
            }
        }
    }
    if(step>1){
        diamond_square(step);
    }
}

void Terrain::square_step(int x, int y, int reach) {
    float sum = 0;
    int cnt=0;
    if(x-reach>=0 && y-reach>=0) {
        sum += height[x-reach][y-reach];
        cnt += 1;
    }
    if(x-reach>=0 && y+reach<size) {
        sum += height[x-reach][y+reach];
        cnt += 1;
    }
    if(x+reach<size && y-reach>=0) {
        sum += height[x+reach][y-reach];
        cnt += 1;
    }
    if(x+reach<size && y+reach<size) {
        sum += height[x+reach][y+reach];
        cnt += 1;
    }
    height[x][y] = sum / cnt + noise(generator);
    if(height[x][y]>max_height) {
        max_height = height[x][y];
    }
}

void Terrain::diamond_step(int x, int y, int step) {
    float sum = 0;
    int cnt=0;
    if(x-step>=0) {
        sum += height[x-step][y];
        cnt += 1;
    }
    if(x+step<size) {
        sum += height[x+step][y];
        cnt += 1;
    }
    if(y-step>=0) {
        sum += height[x][y-step];
        cnt += 1;
    }
    if(y+step<size) {
        sum += height[x][y+step];
        cnt += 1;
    }
    height[x][y] = sum / cnt + noise(generator);
    if(height[x][y]>max_height) {
        max_height = height[x][y];
    }
}

void Terrain::build_terrain() {
    diamond_square(size);
//    for(int i=0; i<size; ++i) {
//        height[i][0] = 0.0f;
//    }
//    for(int i=0; i<size; ++i) {
//        height[i][size-1] = 0.0f;
//    }
//    for(int i=0; i<size; ++i) {
//        height[0][i] = 0.0f;
//    }
//    for(int i=0; i<size; ++i) {
//        height[size-1][i] = 0.0f;
//    }
}

void Terrain::setup_terrain() {
    string filename = "Mountain.png";

    glGenTextures(1, &texture_id);
    glBindTexture(GL_TEXTURE_2D, texture_id);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    unsigned char *data = stbi_load(filename.c_str(), &texture_width, &texture_height, &texture_nc, 0);
    if (data) {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, texture_width, texture_height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);
    } else {
        std::cout << "Failed to load texture" << std::endl;
    }
    stbi_image_free(data);
    
    float sr = texture_width / size;
    float tr = texture_height / size;
    for(int i=0; i<size; ++i) {
        for(int j=0; j<size; ++j) {
            float x = position[i][j][0];
            float z = position[i][j][1];
            float y = height[i][j];
            vertices.push_back(glm::vec3(x, y, z));
            normals.push_back(glm::vec3(x, y, z));
            texture_coordinates.push_back(glm::vec2((i+0.01)*sr, (j+0.01)*tr));
        }
    }
    
    for(int i=0; i<size-1; ++i) {
        for(int j=0; j<size-1; ++j) {
            int id1 = i*size+j;
            int id2 = i*size+j+1;
            int id3 = (i+1)*size + j + 1;
            indices.push_back(glm::uvec3(id1, id3, id2));
            
            id2 = (i+1)*size+j;
            indices.push_back(glm::uvec3(id1, id2, id3));
        }
    }
    
    glGenVertexArrays(1, &VAO);
    
    glGenBuffers(1, &VBO);
    glBindVertexArray(VAO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec3) * vertices.size(), vertices.data(), GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), 0);
    
    glGenBuffers(1, &VBO);
    glBindVertexArray(VAO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec3) * normals.size(), normals.data(), GL_STATIC_DRAW);
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), 0);
    
    glGenBuffers(1, &VBO);
    glBindVertexArray(VAO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec2) * texture_coordinates.size(), texture_coordinates.data(), GL_STATIC_DRAW);
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), 0);

    glGenBuffers(1, &EBO);
    glBindVertexArray(VAO);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(glm::uvec3)*indices.size(), indices.data(), GL_STATIC_DRAW);
    glEnableVertexAttribArray(3);
    glVertexAttribPointer(3, 3, GL_UNSIGNED_INT, GL_FALSE, 3 * sizeof(GL_UNSIGNED_INT), 0);
    
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
}

void Terrain::draw() {
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, texture_id);
    
    glBindVertexArray(VAO);
    glDrawElements(GL_TRIANGLES, indices.size()*3, GL_UNSIGNED_INT, 0);
    //glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
    glBindVertexArray(0);
}

void Terrain::regenerate() {
    build_terrain();
    setup_terrain();
}

//
//  Particle.cpp
//  CSE167_group_proj
//
//  Created by 吴诗慧 on 2020/3/9.
//  Copyright © 2020年 SelenaWu. All rights reserved.
//

#include "Particle.hpp"

Particle::Particle(){
    pos = genRandomPoint();
    initPos = pos;
    velocity = genRandomVelocity();
    decay = float((rand()%100)/20000.0f);
    //std::cout<<"decay"<<decay<<std::endl;
    // Generate a vertex array (VAO) and two vertex buffer objects (VBO).
    glGenVertexArrays(1, &vao);
    glGenBuffers(1, &vbo);
    std::vector<glm::vec3> vertices;
    vertices.push_back(pos);
    //std::cout<<"snow location "<<pos[0]<<" "<<pos[1]<<" "<<pos[2]<<std::endl;
    // Bind to the VAO.
    // This tells OpenGL which data it should be paying attention to
    glBindVertexArray(vao);
    
    // Bind to the first VBO. We will use it to store the points.
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    // Pass in the data.
    //std::vector::data() returns a direct pointer to the memory array used internally by the vector to store its owned elements
    //GL_STATIC_DRAW means the data store contents will be modified once and used many times as the source for GL drawing commands
    glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec3)*vertices.size(),
                 vertices.data(), GL_STATIC_DRAW);
    // Enable vertex attribute 0.
    // We will be able to access points through it.
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), 0);
    
    // Unbind from the VBO.
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    // Unbind from the VAO.
    glBindVertexArray(0);
}

Particle::~Particle(){
    glDeleteBuffers(1, &vbo);
    glDeleteVertexArrays(1, &vao);

}
//change the position of particle, the effect of falling down
void Particle::update(){
    glm::vec3 displacement = velocity + gravity;
    pos += displacement;
    glm::mat4 translateMatrix = glm::translate(glm::mat4(1.0f), displacement);
    model = translateMatrix* model;
    lifetime -= decay;
}

void Particle::draw(){
    if (lifetime < 0)
        restore();
    //SHIHUI TODO::modify the parameter
    //do not render it if fall down below a level
    if (pos[1] < 20.0f)
        restore();
    
    // Bind to the VAO.
    glBindVertexArray(vao);
    // Set point size.
    //glPointSize(3.0);
    glEnable(GL_VERTEX_PROGRAM_POINT_SIZE);
    // Draw points
    glDrawArrays(GL_POINTS, 0, 1);
    // Unbind from the VAO.
    glBindVertexArray(0);

}

void Particle::restore(){
    //std::cout<<"restore"<<std::endl;
    pos = genRandomPoint();
    velocity = genRandomVelocity();
    glm::vec3 dist = pos - initPos;
    glm::mat4 translateMatrix = glm::translate(glm::mat4(1.0f), dist);
    model = translateMatrix * glm::mat4(1.0f);
    lifetime = 1.0f;
}

glm::vec3 Particle::genRandomPoint(){
    //SHIHUI TODO::modify to fit the screen
    return glm::vec3(float((rand()%100 - 50)/1.0f), float((rand()%30+40)/1.0f), float((rand()%100 -50)/1.0f));
}

glm::vec3 Particle::genRandomVelocity(){
    //SHIHUI TODO
    return glm::vec3(float(rand()%100)/5000.0f, 0.0f, float(rand()%100)/5000.0f);
}


//
//  NaiveModel.hpp
//  hw4
//
//  Created by Yaosen Lin on 3/9/20.
//  Copyright © 2020 YaosenLin. All rights reserved.
//

#ifndef NaiveModel_hpp
#define NaiveModel_hpp

#ifdef __APPLE__
#include <OpenGL/gl3.h>
#else
#include <GL/glew.h>
#endif
#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtx/transform.hpp>

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

struct Texture {
    string name;
    glm::vec3 ka;
    glm::vec3 kd;
    glm::vec3 ks;
    bool is_map;
    GLuint id;
};

struct Mesh {
    int texture_id;
    vector<glm::vec3> vertices;
    vector<glm::vec3> normals;
    vector<glm::vec2> TexCoords;
    vector<glm::uvec3> indices;
    GLuint VAO, VBO, EBO;
};


class NaiveModel {
public:
    glm::mat4 model;
    vector<Mesh> meshes;
    vector<Texture> textures;
    string filename;
    NaiveModel(string filename);
    
    void load_mtl();
    void load_mesh();
    void setup_mesh();
    void draw(GLuint shader);
};


#endif /* NaiveModel_hpp */

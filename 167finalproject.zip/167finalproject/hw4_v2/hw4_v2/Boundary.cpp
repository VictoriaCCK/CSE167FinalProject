//
//  TerrainHelper.cpp
//  CSE167_group_proj
//
//  Created by 吴诗慧 on 2020/3/13.
//  Copyright © 2020年 SelenaWu. All rights reserved.
//


#include "Boundary.hpp"

Boundary::Boundary(std::string objFilename, glm::mat4 model_){
    name = objFilename;
    float x_coor, y_coor, z_coor, r, g, b;
    char edge1[20], edge2[20], edge3[20];
    FILE* fp;
    int c1, c2;
    
    const char* path = objFilename.c_str();
    fp = fopen(path, "rb");
    if (fp == NULL){
        std::cout<<"error loading file"<<std::endl;
        exit(-1);
    }
    std::vector<glm::vec3> points_;
    std::vector<glm::vec3> normals_;
    std::vector<GLuint> points_idx;
    std::vector<GLuint> normals_idx;
    //scan the file
    do{
        c1 = fgetc(fp);
        if (c1 == '\n')
            continue;
        c2 = fgetc(fp);
        //process vector information
        if ((c1 == 'v') && (c2 == ' ')){
            fscanf(fp, "%f %f %f\n", &x_coor, &y_coor, &z_coor, &r, &g, &b);
            glm::vec3 vertex = glm::vec3(x_coor, y_coor, z_coor);
            points_.push_back(vertex);
        }
        //read normals
        else if ((c1 == 'v') && (c2 == 'n')){
            fscanf(fp, "%f %f %f\n", &x_coor, &y_coor, &z_coor);
            glm::vec3 vertex = glm::vec3(x_coor, y_coor, z_coor);
            normals_.push_back(vertex);
        }
        //read connections
        
        else if ((c1 == 'f')&& (c2 == ' ')){
            fscanf(fp, "%s %s %s\n", edge1, edge2, edge3);
            //std::cout<<edge1<<" "<<edge2<<" "<<edge3<<std::endl;
            std::string edges[3] = {edge1, edge2, edge3};
            for(std::string str: edges){
                //std::string str = std::string(edge);
                size_t split1 = str.find("/");
                size_t split2 = str.find("/", split1 + 1);
                int vertex = std::atoi(str.substr(0, split1).c_str());
                int normal = std::atoi(str.substr(split2 + 1, std::string::npos).c_str());
                //std::cout<<index<<std::endl;
                points_idx.push_back((unsigned int)(vertex - 1));
                normals_idx.push_back((unsigned int)(normal - 1));
                //indices.push_back(index - 1);
            }
            //std::cout<<e[0]<<" "<<e[1]<<" "<<e[2]<<std::endl;
            //indices.push_back(e_vector);
        }
    }
    while (c1 != EOF && c2 != EOF);
    for (unsigned int i = 0; i < points_idx.size(); i++){
        points.push_back(points_[points_idx[i]]);
        normals.push_back(normals_[normals_idx[i]]);
        indices.push_back(i);
    }
    std::cout<<objFilename<<std::endl;
    std::cout<<"number of vertices "<<points.size()<<std::endl;
    std::cout<<"number of normals "<<normals.size()<<std::endl;
    std::cout<<"number of faces "<< indices.size()<<std::endl;
    //do not have to center the light sphere
    model = model_;
    
    
    // Generate a vertex array (VAO) and two vertex buffer objects (VBO).
    glGenVertexArrays(1, &vao);
    glGenBuffers(2, &vbo[0]);
    
    // Bind to the VAO.
    // This tells OpenGL which data it should be paying attention to
    glBindVertexArray(vao);
    
    // Bind to the first VBO. We will use it to store the points.
    glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
    // Pass in the data.
    glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec3) * points.size(),
                 points.data(), GL_STATIC_DRAW);
    // Enable vertex attribute 0.
    // We will be able to access points through it.
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), 0);
    
    glBindBuffer(GL_ARRAY_BUFFER, vbo[1]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec3) * normals.size(),
                 normals.data(), GL_STATIC_DRAW);
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), 0);
    
    // Unbind from the VBO.
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    
    //bind EBO
    glGenBuffers(1, &ebo);
    
    //glBindVertexArray(vao);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(GLuint)* indices.size(),
                 indices.data(), GL_STATIC_DRAW);
    
    // Unbind from the VAO.
    glBindVertexArray(0);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
}

Boundary::~Boundary()
{
    // Delete the VBO and the VAO.
    // Failure to delete your VAOs, VBOs and other data given to OpenGL
    // is dangerous and may slow your program and cause memory leaks
    glDeleteBuffers(2, &vbo[0]);
    glDeleteVertexArrays(1, &vao);
    glDeleteBuffers(1, &ebo);
}

void Boundary::draw()
{
    //std::cout<<"drawing "<<name<<std::endl;
    //std::cout<<"matrix "<<C[3][0]<<" "<<C[3][1]<<" "<<C[3][2]<<std::endl ;
    // Bind to the VAO.
    glBindVertexArray(vao);
    glDrawElements(GL_TRIANGLES, indices.size(), GL_UNSIGNED_INT, 0);
    // Unbind from the VAO.
    glBindVertexArray(0);
}
